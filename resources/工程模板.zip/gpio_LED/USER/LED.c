#include "stm32f10x.h"
void Delayms(unsigned long u)	//软件延时，靠指令执行时间来延时
{	unsigned long i,j;
	for(i=0;i<u;i++) for(j=0;j<12000;j++);
}

void LED_init()	//GPIO初始化
{
	GPIO_InitTypeDef g1;	//定义GPIO初始化结构体变量g1
//①GPIOA和GPIOD时钟使能
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOD, ENABLE); //使能GPIOA和GPIOD时钟
//②GPIOA 端口模式设置
	g1.GPIO_Pin = GPIO_Pin_8;    //LED0-->PA.8 端口配置
	g1.GPIO_Speed = GPIO_Speed_50MHz;
	g1.GPIO_Mode = GPIO_Mode_Out_OD; //推挽输出
	GPIO_Init(GPIOA, &g1); //初始化 GPIOA.8
//③GPIOD 端口模式设置
	g1.GPIO_Pin = GPIO_Pin_2;    //LED1-->PD.2 端口配置
	g1.GPIO_Speed = GPIO_Speed_50MHz;
	g1.GPIO_Mode = GPIO_Mode_Out_OD; //推挽输出
	GPIO_Init(GPIOD, &g1); //初始化 GPIOD.2
//④ 两个LED都灭掉
	GPIO_SetBits(GPIOA,GPIO_Pin_8);		//PA.8 输出高,LED0灭
	GPIO_SetBits(GPIOD,GPIO_Pin_2);		//PD.2 输出高,LED1灭
}

int main(void)
{
	LED_init();	//初始化LED0和LED1连接的IO口
	while(1)
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_8);		//PA.8 输出低,LED0亮
		GPIO_SetBits(GPIOD,GPIO_Pin_2);			//PD.2 输出高,LED1灭
		Delayms(500);
		GPIO_SetBits(GPIOA,GPIO_Pin_8);				//PA.8 输出高,LED0灭
		GPIO_ResetBits(GPIOD,GPIO_Pin_2);			//PD.2 输出低,LED1亮
		Delayms(500);
	}
}
